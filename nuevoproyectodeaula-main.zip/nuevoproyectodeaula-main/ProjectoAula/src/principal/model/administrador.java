/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal.model;

/**
 *
 * @author Asus Vivobook
 */
public class administrador {
    
    private String usuario;
    private int clave;
    private int id;
    private String gmail;
    private String codigo;
    
    
   public administrador(){
    this.usuario = usuario;
    this.clave = clave;
    this. id = id;
    this.gmail = gmail;
    this.codigo = codigo;
   
   }

    /**
     * @return the usuario
     */
    private String getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    private void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the clave
     */
    private int getClave() {
        return clave;
    }

    /**
     * @param clave the clave to set
     */
    private void setClave(int clave) {
        this.clave = clave;
    }

    /**
     * @return the id
     */
    private int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    private void setId(int id) {
        this.id = id;
    }

    /**
     * @return the gmail
     */
    private String getGmail() {
        return gmail;
    }

    /**
     * @param gmail the gmail to set
     */
    private void setGmail(String gmail) {
        this.gmail = gmail;
    }

    /**
     * @return the codigo
     */
    private String getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    private void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
    
}

